print "Running HTTP client"
exec "curl" args
